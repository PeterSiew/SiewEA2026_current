import numpy as np
import os
import ipdb


url_link='https://climexp.knmi.nl/CMIP5/Tglobal'
#filelists=np.genfromtxt('./file_list.txt')
filelists=np.loadtxt('./file_list.txt',dtype='str')
for fl in filelists:
    bash_command='wget %s/%s'%(url_link,fl)
    os.system(bash_command)

